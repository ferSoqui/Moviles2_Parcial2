//
//  Producto.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import Foundation

struct Producto {
    var nombre: String
    var precio: String
    var imagen: String
    var sonido: String
}
