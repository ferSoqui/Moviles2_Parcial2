//
//  CategoriaAlimento.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import Foundation

struct CategoriaAlimento {
    var nombre: String
    var productos: [Producto]
}
