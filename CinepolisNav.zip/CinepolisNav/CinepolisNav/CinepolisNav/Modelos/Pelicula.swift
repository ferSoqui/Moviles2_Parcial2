//
//  Pelicula.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import Foundation

struct Pelicula {
    var nombre: String
    var imagen: String
    var anio: Int
    var genero: String
    var duracion: String
}
