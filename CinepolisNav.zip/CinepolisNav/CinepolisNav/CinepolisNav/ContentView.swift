//
//  ContentView.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            ListMovieView()
                .navigationTitle("Cartelera")
        }
    }
}

#Preview {
    ContentView()
}
