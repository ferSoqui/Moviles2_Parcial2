//
//  CategoriasViewModel.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import Foundation

struct CategoriasViewModel {

    func getCategorias() -> [CategoriaAlimento] {
        return [
            CategoriaAlimento(nombre: "Palomitas", productos: [
                Producto(nombre: "Palomitas Chicas", precio: "$45", imagen: "palomitas", sonido: "sonido_palomitas"),
                Producto(nombre: "Palomitas Grandes", precio: "$65", imagen: "palomitas", sonido: "sonido_palomitas")
            ]),
            CategoriaAlimento(nombre: "Bebidas", productos: [
                Producto(nombre: "Refresco Chico", precio: "$35", imagen: "refresco", sonido: "sonido_refresco"),
                Producto(nombre: "Refresco Grande", precio: "$50", imagen: "refresco", sonido: "sonido_refresco")
            ]),
            CategoriaAlimento(nombre: "Dulces", productos: [
                Producto(nombre: "Nachos", precio: "$55", imagen: "nachos", sonido: "sonido_nachos"),
                Producto(nombre: "Chocolate", precio: "$30", imagen: "chocolate", sonido: "sonido_dulce")
            ])
        ]
    }
}
