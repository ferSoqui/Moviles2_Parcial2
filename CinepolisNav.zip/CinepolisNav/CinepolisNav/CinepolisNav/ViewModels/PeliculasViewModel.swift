//
//  PeliculasViewModel.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import Foundation

struct PeliculasViewModel {

    func getPeliculas() -> [Pelicula] {
        return [
            Pelicula(nombre: "Top Gun", imagen: "topgun", anio: 2022, genero: "Acción/Aventura", duracion: "2h 11min"),
            Pelicula(nombre: "Regretting You", imagen: "regrettingyou", anio: 2025, genero: "Drama/Romance", duracion: "1h 55min"),
            Pelicula(nombre: "Hangover", imagen: "hangover", anio: 2009, genero: "Comedia", duracion: "1h 40min"),
            Pelicula(nombre: "Spider-Man", imagen: "spiderman", anio: 2021, genero: "Acción/Sci-Fi", duracion: "2h 28min")
        ]
    }
}
