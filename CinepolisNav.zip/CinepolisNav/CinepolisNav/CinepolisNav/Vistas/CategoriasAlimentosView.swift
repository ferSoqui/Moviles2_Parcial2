//
//  CategoriasAlimentosView.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct CategoriasAlimentosView: View {

    var categorias: [CategoriaAlimento] = CategoriasViewModel().getCategorias()

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                ForEach(categorias.indices, id: \.self) { index in

                    NavigationLink(destination: ProductosView(categoria: categorias[index])) {
                        HStack {
                            Text(categorias[index].nombre)
                                .font(.headline)
                                .foregroundColor(.primary)

                            Spacer()

                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Dulcería")
    }
}

#Preview {
    NavigationStack {
        CategoriasAlimentosView()
    }
}
