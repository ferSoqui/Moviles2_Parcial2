//
//  ListMovieView.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct ListMovieView: View {

    var peliculas: [Pelicula] = PeliculasViewModel().getPeliculas()

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ForEach(peliculas.indices, id: \.self) { index in

                    NavigationLink(destination: SinopsisView(pelicula: peliculas[index])) {
                        VStack {
                            Image(peliculas[index].imagen)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 180, height: 270)
                                .cornerRadius(12)
                                .shadow(radius: 4)

                            Text(peliculas[index].nombre)
                                .font(.title3)
                                .foregroundColor(.primary)
                                .multilineTextAlignment(.center)

                            Text("Ver Sinopsis")
                                .foregroundStyle(Color.blue)
                        }
                    }
                }
            }
            .padding()
        }
    }
}

#Preview {
    NavigationStack {
        ListMovieView()
    }
}
