//
//  CinepolisNavApp.swift
//  CinepolisNav
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

@main
struct CinepolisNavApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
