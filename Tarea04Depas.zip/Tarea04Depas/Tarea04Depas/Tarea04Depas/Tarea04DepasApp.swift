//
//  Tarea04DepasApp.swift
//  Tarea04Depas
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

@main
struct Tarea04DepasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
