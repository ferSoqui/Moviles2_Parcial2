//
//  DepartamentosListView.swift
//  Tarea04Depas
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct DepartamentosListView: View {

    @State var departamentoReservado: Int = 0

    @State var favorito1: Bool = false
    @State var favorito2: Bool = false
    @State var favorito3: Bool = false
    @State var favorito4: Bool = false
    @State var favorito5: Bool = false

    @State var marcarTodos: Bool = false

    var todosMarcados: Bool {
        marcarTodos || (favorito1 && favorito2 && favorito3 && favorito4 && favorito5)
    }

    var body: some View {

        ScrollView(.vertical, showsIndicators: true) {

            VStack(alignment: .leading, spacing: 16) {

                Text("Departamentos")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.horizontal)

                Toggle("Marcar todos como favoritos", isOn: $marcarTodos)
                    .padding(.horizontal)

                if todosMarcados {
                    GroupBox {
                        Text("Todos han sido marcados")
                    }
                    .padding(.horizontal)
                }

                DepartamentoCardView(
                    id: 1,
                    imagen: "depa01",
                    ubicacion: "Ampliación, Cd Madero",
                    nombre: "GH Raíces | 1F",
                    precio: "$25,000",
                    superficie: "29.02 m2",
                    calificacion: "4.7",
                    departamentoReservado: $departamentoReservado,
                    favorito: $favorito1,
                    todosMarcados: marcarTodos
                )

                DepartamentoCardView(
                    id: 2,
                    imagen: "depa02",
                    ubicacion: "Petrolera, Tampico",
                    nombre: "Hmlet Raíces | 8F",
                    precio: "$14,960",
                    superficie: "26.15 m2",
                    calificacion: "4.5",
                    departamentoReservado: $departamentoReservado,
                    favorito: $favorito2,
                    todosMarcados: marcarTodos
                )

                DepartamentoCardView(
                    id: 3,
                    imagen: "depa03",
                    ubicacion: "Miralta, Altamira",
                    nombre: "Oak Century | 5F",
                    precio: "$16,400",
                    superficie: "25.08 m2",
                    calificacion: "4.7",
                    departamentoReservado: $departamentoReservado,
                    favorito: $favorito3,
                    todosMarcados: marcarTodos
                )

                DepartamentoCardView(
                    id: 4,
                    imagen: "depa04",
                    ubicacion: "Los Mangos, Madero",
                    nombre: "Fontana SH | 4F",
                    precio: "$17,300",
                    superficie: "27.22 m2",
                    calificacion: "4.6",
                    departamentoReservado: $departamentoReservado,
                    favorito: $favorito4,
                    todosMarcados: marcarTodos
                )

                DepartamentoCardView(
                    id: 5,
                    imagen: "depa05",
                    ubicacion: "Grossman, Altamira",
                    nombre: "Homestay Iest | 4F",
                    precio: "$18,500",
                    superficie: "25.74 m2",
                    calificacion: "5.0",
                    departamentoReservado: $departamentoReservado,
                    favorito: $favorito5,
                    todosMarcados: marcarTodos
                )
            }
            .padding(.vertical)
        }
    }
}

#Preview {
    DepartamentosListView()
}
