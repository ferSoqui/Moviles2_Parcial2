//
//  DepartamentoDetalleView.swift
//  Tarea04Depas
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct DepartamentoDetalleView: View {

    var imagen: String
    var nombre: String
    var ubicacion: String
    var precio: String
    var caracteristica1: String
    var caracteristica2: String
    var caracteristica3: String
    var caracteristica4: String
    var caracteristica5: String
    var imagenDiagrama: String

    @State var mostrarModal: Bool = false

    var body: some View {

        ScrollView {

            VStack(alignment: .leading, spacing: 16) {

                Image(imagen)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                Text(nombre)
                    .font(.title2)
                    .fontWeight(.bold)

                Text(ubicacion)
                    .foregroundColor(.gray)

                Text(precio)
                    .font(.title3)
                    .fontWeight(.bold)

                Text("Características")
                    .font(.headline)
                    .padding(.top, 8)

                Label(caracteristica1, systemImage: "checkmark.circle")
                Label(caracteristica2, systemImage: "checkmark.circle")
                Label(caracteristica3, systemImage: "checkmark.circle")
                Label(caracteristica4, systemImage: "checkmark.circle")
                Label(caracteristica5, systemImage: "checkmark.circle")

                Button(action: {
                    mostrarModal = true
                }) {
                    Text("Ver diagrama y más fotos")
                        .fontWeight(.bold)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.top, 8)
            }
            .padding()
        }
        .navigationTitle(nombre)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $mostrarModal) {
            DepartamentoDiagramaView(imagenDiagrama: imagenDiagrama)
        }
    }
}

#Preview {
    DepartamentoDetalleView(
        imagen: "depa01",
        nombre: "GH Raíces | 1F",
        ubicacion: "Ampliación, Cd Madero",
        precio: "$25,000 al mes",
        caracteristica1: "29.02 m2",
        caracteristica2: "1 recámara",
        caracteristica3: "Escritorio incluido",
        caracteristica4: "Aire acondicionado",
        caracteristica5: "WiFi incluido",
        imagenDiagrama: "diagrama01"
    )
}
