//
//  DepartamentoCardView.swift
//  Tarea04Depas
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct DepartamentoCardView: View {

    var id: Int
    var imagen: String
    var ubicacion: String
    var nombre: String
    var precio: String
    var superficie: String
    var calificacion: String

    @Binding var departamentoReservado: Int
    @Binding var favorito: Bool
    var todosMarcados: Bool

    @State var showAlert: Bool = false

    var esFavorito: Bool {
        favorito || todosMarcados
    }

    var estaReservado: Bool {
        departamentoReservado == id
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {

            ZStack {

                Image(imagen)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                if estaReservado {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.black.opacity(0.5))
                        .frame(height: 200)

                    Text("Reservado")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }

                VStack {
                    HStack {
                        HStack(spacing: 4) {
                            Image(systemName: "location")
                            Text(ubicacion)
                                .font(.caption)
                        }
                        .foregroundColor(.white)
                        .padding(8)
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(20)

                        Spacer()

                        Button(action: {
                            withAnimation() {
                                favorito.toggle()
                            }
                            showAlert = true
                        }) {
                            Image(systemName: esFavorito ? "heart.fill" : "heart")
                                .foregroundColor(.white)
                                .padding(8)
                                .background(Color.black.opacity(0.5))
                                .clipShape(Circle())
                        }
                    }

                    Spacer()

                    Button(action: {
                        withAnimation() {
                            if estaReservado {
                                departamentoReservado = 0
                            } else {
                                departamentoReservado = id
                            }
                        }
                    }) {
                        Text(estaReservado ? "Cancelar" : "Reservar")
                            .fontWeight(.bold)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(50)
                    }
                }
                .padding(12)
                .frame(height: 200)
            }

            Text(nombre)
                .font(.subheadline)
                .fontWeight(.bold)

            HStack {
                Text(precio)
                    .fontWeight(.bold)
                Text("al mes")
                    .foregroundColor(.gray)

                Spacer()

                Text(superficie)
                    .foregroundColor(.gray)

                Image(systemName: "star.fill")
                    .foregroundColor(.yellow)
                Text(calificacion)
            }
            .font(.subheadline)

            NavigationLink(destination: DepartamentoDetalleView(
                imagen: imagen,
                nombre: nombre,
                ubicacion: ubicacion,
                precio: precio + " al mes",
                caracteristica1: superficie,
                caracteristica2: "1 recámara",
                caracteristica3: "Escritorio incluido",
                caracteristica4: "Aire acondicionado",
                caracteristica5: "WiFi incluido",
                imagenDiagrama: imagen
            )) {
                Text("Ver detalles")
                    .fontWeight(.semibold)
                    .foregroundColor(.blue)
            }
        }
        .modifier(CardViewModifier())
        .alert(Text("Departamento de \(ubicacion) ha sido establecido como preferido exitosamente"), isPresented: $showAlert) {
        }
    }
}

#Preview {
    DepartamentoCardView(
        id: 1,
        imagen: "depa01",
        ubicacion: "Ampliación, Cd Madero",
        nombre: "GH Raíces | 1F",
        precio: "$25,000",
        superficie: "29.02 m2",
        calificacion: "4.7",
        departamentoReservado: .constant(0),
        favorito: .constant(false),
        todosMarcados: false
    )
}
