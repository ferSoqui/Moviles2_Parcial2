//
//  DepartamentoDiagramaView.swift
//  Tarea04Depas
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct DepartamentoDiagramaView: View {

    var imagenDiagrama: String

    var body: some View {
        VStack(spacing: 16) {

            Text("Diagrama y más fotos")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.top)

            Image(imagenDiagrama)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxHeight: 300)
                .clipShape(RoundedRectangle(cornerRadius: 12))

            Text("Más fotos")
                .font(.headline)

            ScrollView(.horizontal, showsIndicators: true) {
                HStack(spacing: 12) {
                    Image("depa01")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 150, height: 150)
                        .clipShape(RoundedRectangle(cornerRadius: 8))

                    Image("depa02")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 150, height: 150)
                        .clipShape(RoundedRectangle(cornerRadius: 8))

                    Image("depa03")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 150, height: 150)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                .padding(.horizontal)
            }

            Spacer()
        }
        .padding()
    }
}

#Preview {
    DepartamentoDiagramaView(imagenDiagrama: "depa01")
}
