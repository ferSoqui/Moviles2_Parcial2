//
//  ContentView.swift
//  Tarea04Depas
//
//  Created by Fernanda Soqui on 07/10/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            DepartamentosListView()
        }
    }
}

#Preview {
    ContentView()
}
